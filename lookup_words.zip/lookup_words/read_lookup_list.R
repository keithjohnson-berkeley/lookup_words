d <- read.csv("testlist.out")

d$stress <- factor(d$stress)
d$sylls <- factor(d$sylls)
d$sfamil <- factor(d$sfam)

